import React from 'react'

const NotFound = () => <h2>Are you lost ?</h2>

export default NotFound
