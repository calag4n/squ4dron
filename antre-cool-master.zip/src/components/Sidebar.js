import React, { Component } from 'react'

import config from '../config'

class Sidebar extends Component {


  render () {
    return (
      <h1>Hello</h1>
    )
  }
}

export default Sidebar
