export default {
  apiKey: "AIzaSyDIr2ztE9qOQeAtjldnDB6pEhJRG3CMUpQ",
  authDomain: "antre-cool.firebaseapp.com",
  databaseURL: "https://antre-cool.firebaseio.com",
  projectId: "antre-cool",
  storageBucket: "antre-cool.appspot.com",
  messagingSenderId: "425137858598"
}